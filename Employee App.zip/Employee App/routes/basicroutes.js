const express=require('express');
const router=express.Router();
const methodOverride = require('method-override');

const employeeModel=require('../model/employeeData');
router.use(express.json());
router.use(express.urlencoded({extended:true}));
router.use(methodOverride('_method')); // Middleware to handle method override




// GET OPERATION

router.get('/',async (req,res)=>{
    try {
        const data=await employeeModel.find();
        res.render('employee',{
            title:"Employee List",
            data
        });
    } catch (error) {
        res.status(404).send("ERROR IS RETRIEVING");
    }
})

// POST OPERATION

// GET route to render the Add Employee form
router.get('/addemployee', (req, res) => {
    res.render('addemployee', {
        title: "Add New Employee"
    });
}); 

router.post('/addemployee',async (req,res)=>{
    try {
        const newEmployee = new employeeModel({ 
        EmployeeName: req.body.EmployeeName,
        EmployeeDesignation: req.body.EmployeeDesignation,
        EmployeeLocation: req.body.EmployeeLocation,
        Salary: req.body.Salary
    })
        await newEmployee.save();
        res.redirect('/employee');
    } catch (error) {
        res.status(404).send("POST OPERATION FAILED");
    }
})

router.get('/editemployee/:id', async (req, res) => {
    try {
        const employee = await employeeModel.findById(req.params.id);
        if (!employee) {
            return res.status(404).send('Employee not found');
        }
        res.render('editemployee', {
            title: "Edit Employee",
            employee // Pass employee data to the view for prefilling the form
        });
    } catch (error) {
        res.status(404).send("ERROR IN FETCHING EMPLOYEE DATA FOR EDIT");
    }
});

// PUT operation to update an existing employee
router.put('/editemployee/:id', async (req, res) => {
    try {
        const updatedEmployee = await employeeModel.findByIdAndUpdate(req.params.id, {
            EmployeeName: req.body.EmployeeName,
            EmployeeDesignation: req.body.EmployeeDesignation,
            EmployeeLocation: req.body.EmployeeLocation,
            Salary: req.body.Salary
        }, { new: true });

        if (!updatedEmployee) {
            return res.status(404).send('Employee not found for updating');
        }
        res.redirect('/employee');
    } catch (error) {
        res.status(500).send("UPDATE OPERATION FAILED");
    }
});

// DELETE operation to remove an employee
router.delete('/deleteemployee/:id', async (req, res) => {
    try {
        const deletedEmployee = await employeeModel.findByIdAndDelete(req.params.id);

            
        
        res.redirect('/employee'); // Redirect to the employee list after deletion
    } catch (error) {
        res.status(404).send("DELETE OPERATION FAILED");
    }
});



//PUT OPERATION


// router.get('/edit/:id', (req, res) => {
//     res.render('upemployee', {
//         title: "Add New Employee"
//     });
// }); 

// router.put('/edit/:id',async (req,res)=>{
//     try {
//         const id=req.params.id;
//         const data=await employeeModel.findByIdAndUpdate(id,req.body);
//         res.status(200).send("UPDATION DONE SUCCESSFULLY")

//     } catch (error) {
//         res.status(404).send("FAILURE IN UPDATION");
//     }
// })




// // DELETE OPERATION

// router.delete('/delete/:id',async (req,res)=>{
//     try {
//         const id=req.params.id;
//         const data=await employeeModel.findByIdAndDelete(id);
//         res.status(200).send("DELETION DONE SUCCESSFULLY")
//     } catch (error) {
//         res.status(404).send("FAILURE IN DELETION");
//     }
// });

// router.get('/edit/:id', async (req, res) => {
//     try {
//         const employee = await employeeModel.findById(req.params.id);
//         res.render('updateemployee', {
//             title: "Update Employee",
//             employee: employee
//         });
//     } catch (error) {
//         res.status(404).send("Employee not found");
//     }
// });

// router.put('/edit/:id', async (req, res) => {
//     try {
//         const id = req.params.id;
//         await employeeModel.findByIdAndUpdate(id, req.body);
//         res.redirect('/');
//     } catch (error) {
//         res.status(404).send("FAILURE IN UPDATION");
//     }
// });

// // DELETE OPERATION

// router.delete('/delete/:id', async (req, res) => {
//     try {
//         const id = req.params.id;
//         await employeeModel.findByIdAndDelete(id);
//         res.status(200).send("DELETION DONE SUCCESSFULLY");
//     } catch (error) {
//         res.status(404).send("FAILURE IN DELETION");
//     }
// });


// router.get('/edit/:id', async (req, res) => {
//     const emp = await employeeModel.findById(req.params.id);
//     res.render('edit', { emp });
// });
// router.post('/edit/:id', async (req, res) => {
//     const empUpdate=req.body
//     console.log( empUpdate)
//     const data= await employeeModel.findByIdAndUpdate(req.params.id, {
//                 empName: req.body.empName,
//                 empDesgn: req.body.empDesgn,
//                 empLocation: req.body.empLocation,
//                 empSalary: req.body.empSalary

//     });
//     console.log(data)
//     res.redirect('/');
// });

// router.post('/delete/:id', async (req, res) => {
//     await employeeModel.findByIdAndDelete(req.params.id);
//     res.redirect('/');
// });
// return empRoute;





module.exports=router;