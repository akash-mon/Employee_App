const mongoose=require('mongoose');

require('dotenv').config();
const mongoURL=process.env.mongoURL;

mongoose.connect(mongoURL).then(()=>{
    console.log('connection established');
}).catch(()=>{
    console.log('connection unestablished');
})
