const express=require('express');
const app=new express();

require('dotenv').config();
const port=process.env.port

const morgan=require('morgan');
app.use(morgan('dev'));

app.set('view engine','ejs');
app.set('views',__dirname+'/views');

const route=require('./routes/basicroutes');
app.use('/employee',route);

require('./db/connection');


app.listen(port,()=>{
    console.log(`successfully running on port ${port}`);
});


